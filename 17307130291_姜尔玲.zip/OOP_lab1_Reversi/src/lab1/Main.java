package lab1;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        Servicer servicer = new Servicer();
        servicer.start_service();
    }
}
